(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_1c112440._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_1c112440._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_566b6fa8._.js",
    "static/chunks/node_modules_828752f3._.js",
    "static/chunks/src_22cfcee0._.js"
  ],
  "source": "dynamic"
});
