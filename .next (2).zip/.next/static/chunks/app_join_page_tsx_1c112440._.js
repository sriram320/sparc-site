(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_join_page_tsx_1c112440._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_join_page_tsx_1c112440._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f43f6b77._.js",
    "static/chunks/src_components_92ea2ba2._.js",
    "static/chunks/node_modules_5087d358._.js"
  ],
  "source": "dynamic"
});
