"use client";

import { Card } from "./card";

interface GoogleFormProps {
    formUrl: string;
    className?: string;
    height?: number;
}

export function GoogleForm({ formUrl, className = "", height = 900 }: GoogleFormProps) {
    return (
        <Card className={`google-form-wrapper ${className}`}>
            <iframe
                src={formUrl}
                width="100%"
                height={height}
                frameBorder="0"
                marginHeight="0"
                marginWidth="0"
                title="Google Form"
            >
                Loading...
            </iframe>
        </Card>
    );
}
