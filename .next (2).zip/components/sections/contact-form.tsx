
"use client";

import { useForm } from "react-hook-form";
import { useActionState } from "react"; // Corrected import for server actions
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { submitContactForm, type ContactFormState } from "@/lib/actions";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send, CheckCircle, AlertTriangle } from "lucide-react";

const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Invalid email address." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export function ContactForm() {
  const { toast } = useToast();
  const [formState, formAction] = useActionState<ContactFormState | undefined, FormData>(submitContactForm, undefined);
  
  const { 
    register, 
    handleSubmit, 
    formState: { errors, isSubmitting }, // This 'formState' (containing 'errors') is from useForm
    reset 
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
  });

  useEffect(() => {
    if (formState?.success) {
      toast({
        title: "Message Sent!",
        description: formState.message,
        variant: "default",
        action: <CheckCircle className="text-green-500" />,
      });
      reset(); // Reset form fields
    } else if (formState && formState.message && formState.errors) {
       toast({
        title: "Submission Error",
        description: formState.message,
        variant: "destructive",
        action: <AlertTriangle className="text-yellow-500" />,
      });
    }
  }, [formState, toast, reset]);

  // Helper to display specific field errors from useActionState (server) or useForm (client)
  const getFieldError = (fieldName: keyof ContactFormData) => {
    return formState?.errors?.[fieldName]?.[0] || errors[fieldName]?.message;
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
            Get In Touch
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-foreground/80">
            Have a question or a project proposal? We'd love to hear from you.
          </p>
        </div>

        <Card className="max-w-xl mx-auto shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl">Send Us a Message</CardTitle>
            <CardDescription>Fill out the form below, and we'll get back to you as soon as possible.</CardDescription>
          </CardHeader>
          <CardContent>
            <form action={formAction} onSubmit={handleSubmit(() => formAction(new FormData(document.getElementById("contact-form-element") as HTMLFormElement)))} className="space-y-6" id="contact-form-element">
              <div>
                <Label htmlFor="name" className="block text-sm font-medium text-foreground/90 mb-1">Full Name</Label>
                <Input 
                  id="name" 
                  type="text"
                  {...register("name")} 
                  placeholder="Your Name" 
                  className="text-base"
                  aria-invalid={!!getFieldError("name")}
                />
                {getFieldError("name") && <p className="mt-1 text-sm text-destructive">{getFieldError("name")}</p>}
              </div>

              <div>
                <Label htmlFor="email" className="block text-sm font-medium text-foreground/90 mb-1">Email Address</Label>
                <Input 
                  id="email" 
                  type="email"
                  {...register("email")} 
                  placeholder="you@example.com" 
                  className="text-base"
                  aria-invalid={!!getFieldError("email")}
                />
                {getFieldError("email") && <p className="mt-1 text-sm text-destructive">{getFieldError("email")}</p>}
              </div>

              <div>
                <Label htmlFor="message" className="block text-sm font-medium text-foreground/90 mb-1">Your Message</Label>
                <Textarea 
                  id="message"
                  {...register("message")} 
                  placeholder="Tell us about your inquiry or project idea..." 
                  rows={5}
                  className="text-base"
                  aria-invalid={!!getFieldError("message")}
                />
                {getFieldError("message") && <p className="mt-1 text-sm text-destructive">{getFieldError("message")}</p>}
              </div>
              
              {formState?.errors?._form && (
                <div className="p-3 bg-destructive/10 text-destructive border border-destructive/20 rounded-md flex items-start">
                  <AlertTriangle className="h-5 w-5 mr-2 mt-0.5 shrink-0" />
                  <p className="text-sm">{formState.errors._form.join(', ')}</p>
                </div>
              )}

              <Button type="submit" disabled={isSubmitting} className="w-full group">
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    Send Message
                    <Send className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
