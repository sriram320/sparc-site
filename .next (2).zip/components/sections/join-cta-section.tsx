import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Briefcase, ArrowRight } from 'lucide-react';

export function JoinCtaSection() {
  return (
    <section id="join-cta" className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4 text-center">
        <Briefcase className="mx-auto h-12 w-12 text-primary mb-6" />
        <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl mb-6 animate-fadeInUp" style={{ animationDelay: '0.1s' }}>
          Ready to Shape the Future of Aerospace?
        </h2>
        <p className="mt-4 max-w-2xl mx-auto text-lg text-foreground/80 mb-8 animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
          We are always looking for passionate and talented individuals to join our mission.
          Explore exciting career opportunities at Sparc Launchpad.
        </p>
        <div className="animate-fadeInUp" style={{ animationDelay: '0.3s' }}>
          <Link href="/join">
            <Button size="lg" className="group shadow-lg hover:shadow-xl transition-shadow duration-300">
              View Openings & Join Our Team
              <ArrowRight className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
