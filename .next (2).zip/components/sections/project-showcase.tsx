import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: 'Project Nova: Reusable Rocket Engine',
    description: 'Developing a next-generation reusable rocket engine for sustainable space exploration and reduced launch costs.',
    imageUrl: 'https://placehold.co/600x400.png',
    imageHint: 'rocket engine launch',
    tags: ['Propulsion', 'Reusability', 'Sustainability'],
  },
  {
    id: 2,
    title: 'Orion Satellite Constellation',
    description: 'A network of advanced LEO satellites providing global high-speed internet coverage and Earth observation data.',
    imageUrl: 'https://placehold.co/600x400.png',
    imageHint: 'satellite network space',
    tags: ['Satellites', 'Communication', 'Earth Observation'],
  },
  {
    id: 3,
    title: 'Lunar Gateway Habitation Module',
    description: 'Contributing to the Artemis program by designing and building a key habitation module for the Lunar Gateway space station.',
    imageUrl: 'https://placehold.co/600x400.png',
    imageHint: 'space station module moon',
    tags: ['Space Stations', 'Lunar Exploration', 'Habitation'],
  },
  {
    id: 4,
    title: 'AI-Powered Mission Control',
    description: 'Implementing advanced AI algorithms for autonomous mission control, enhancing safety and efficiency of space operations.',
    imageUrl: 'https://placehold.co/600x400.png',
    imageHint: 'mission control AI',
    tags: ['Artificial Intelligence', 'Mission Control', 'Autonomy'],
  },
];

export function ProjectShowcase() {
  return (
    <section id="projects" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
            Our Innovations
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-foreground/80">
            A glimpse into the pioneering projects driving Sparc Aerospace forward.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2">
          {projects.map((project, index) => (
            <Card 
              key={project.id} 
              className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-1 group animate-fadeInUp"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader className="p-0">
                <div className="relative h-60 w-full">
                  <Image
                    src={project.imageUrl}
                    alt={project.title}
                    data-ai-hint={project.imageHint}
                    layout="fill"
                    objectFit="cover"
                    className="transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <CardTitle className="text-xl font-semibold mb-2 text-foreground">{project.title}</CardTitle>
                <CardDescription className="text-muted-foreground mb-4 leading-relaxed h-20 overflow-hidden"> {/* Fixed height for uniform look */}
                  {project.description}
                </CardDescription>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-full font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full group/button">
                  Learn More
                  <ExternalLink className="ml-2 h-4 w-4 transform transition-transform duration-300 group-hover/button:translate-x-1" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
