import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, Eye, Users, Zap } from 'lucide-react';

const overviewItems = [
  {
    icon: Target,
    title: 'Our Mission',
    description: 'To accelerate aerospace innovation through cutting-edge research, development, and collaboration, making space more accessible and sustainable for future generations.',
  },
  {
    icon: Eye,
    title: 'Our Vision',
    description: 'To be a global leader in aerospace technology, pioneering solutions that push the boundaries of exploration and improve life on Earth through space-derived insights.',
  },
  {
    icon: Zap,
    title: 'Core Values',
    description: 'Innovation, Excellence, Integrity, Collaboration, and Sustainability. These principles guide every decision we make and every project we undertake.',
  },
  {
    icon: Users,
    title: 'Our Team',
    description: 'Comprised of visionary engineers, scientists, and strategists, our team is united by a passion for space and a commitment to achieving the extraordinary.',
  },
];

export function CompanyOverview() {
  return (
    <section id="overview" className="py-16 md:py-24 bg-secondary/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
            About Sparc Aerospace
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-foreground/80">
            Fueling the next era of space exploration and technological advancement.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2">
          {overviewItems.map((item, index) => (
            <Card 
              key={item.title} 
              className="flex flex-col group bg-card shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-1 animate-fadeInUp"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader className="flex flex-row items-center space-x-4 pb-4">
                <div className="p-3 rounded-full bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                  <item.icon className="h-7 w-7" />
                </div>
                <CardTitle className="text-xl font-semibold text-foreground">{item.title}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
