"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { GoogleForm } from "../ui/google-form";

const GOOGLE_FORM_EMBED_URL = "https://docs.google.com/forms/d/e/1FAIpQLSeulJyp7rJEAzRjlokNqS1AZ072vnf5_A_3WCJ8A1GM5Wc_WQ/viewform?embedded=true";

export function JoinForm() {
  return (
    <Card className="max-w-4xl mx-auto shadow-xl border border-border/30 rounded-lg">
      <CardHeader>
        <CardTitle className="text-2xl text-primary">Aspiring Innovator Application</CardTitle>
        <CardDescription className="text-foreground/80">
          We're excited to learn more about you! Fill out the form below to apply.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <GoogleForm 
          formUrl={GOOGLE_FORM_EMBED_URL} 
          height={1000}
          className="rounded-b-lg overflow-hidden"
        />
      </CardContent>
    </Card>
  );
}
