import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { ScrollLink } from '@/components/layout/scroll-link';

export function Hero() {
  return (
    <section
      id="hero"
      className="relative flex min-h-[calc(100vh-4rem)] items-center justify-center overflow-hidden py-20 md:py-32"
    >
      <div className="absolute inset-0 z-0">
        <Image
          src="https://placehold.co/1920x1080.png"
          alt="Futuristic space background"
          data-ai-hint="futuristic space"
          layout="fill"
          objectFit="cover"
          quality={80}
          className="opacity-20"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background z-10"></div>
      </div>
      
      <div className="container relative z-10 mx-auto px-4 text-center">
        <h1 className="animate-fadeInUp text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-7xl [animation-delay:0.2s]">
          <span className="block">Sparc Launchpad:</span>
          <span className="block text-primary">Pioneering Aerospace</span>
        </h1>
        <p className="animate-fadeInUp mx-auto mt-6 max-w-xl text-lg text-foreground/80 sm:text-xl md:max-w-2xl [animation-delay:0.4s]">
          Embark on a journey with Sparc Aerospace as we redefine the boundaries of space technology and innovation. Explore our groundbreaking projects and join us in shaping the future.
        </p>
        <div className="animate-fadeInUp mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row [animation-delay:0.6s]">
          <ScrollLink href="#projects">
            <Button size="lg" className="w-full sm:w-auto group shadow-lg hover:shadow-xl transition-shadow duration-300">
              Explore Our Projects
              <ArrowRight className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
            </Button>
          </ScrollLink>
          <ScrollLink href="#contact">
            <Button variant="outline" size="lg" className="w-full sm:w-auto shadow-md hover:shadow-lg transition-shadow duration-300">
              Get In Touch
            </Button>
          </ScrollLink>
        </div>
      </div>
       {/* Subtle 3D accent: decorative shapes - optional, can be expanded */}
       <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-primary/10 rounded-full filter blur-3xl opacity-50 z-0 hidden md:block"></div>
       <div className="absolute -top-20 -right-20 w-72 h-72 bg-accent/10 rounded-full filter blur-3xl opacity-50 z-0 hidden md:block"></div>
    </section>
  );
}
