import Link from 'next/link';
import { Rocket, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import type React from 'react';
import { ScrollLink } from './scroll-link';

const navItems = [
  { href: '#overview', label: 'Overview' },
  { href: '#projects', label: 'Projects' },
  { href: '/join', label: 'Join Us' },
  { href: '#contact', label: 'Contact' },
];

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between px-4 md:px-8">
        <Link href="/" className="flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors">
          <Rocket className="h-7 w-7" />
          <span className="font-bold text-xl tracking-tight">Sparc Launchpad</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => (
            item.href.startsWith('#') ? (
              <ScrollLink
                key={item.label}
                href={item.href}
                className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors"
              >
                {item.label}
              </ScrollLink>
            ) : (
              <Link
                key={item.label}
                href={item.href}
                className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors"
              >
                {item.label}
              </Link>
            )
          ))}
        </nav>

        {/* Mobile Navigation */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] bg-background p-6">
              <div className="flex flex-col space-y-6">
                <Link href="/" className="flex items-center space-x-2 text-primary">
                  <Rocket className="h-7 w-7" />
                  <span className="font-bold text-xl">Sparc Launchpad</span>
                </Link>
                <nav className="flex flex-col space-y-4">
                  {navItems.map((item) => (
                     <SheetClose asChild key={item.label}>
                       {item.href.startsWith('#') ? (
                          <ScrollLink                          
                            href={item.href}
                            className="text-lg font-medium text-foreground/80 hover:text-primary transition-colors py-2 block"
                          >
                            {item.label}
                          </ScrollLink>
                       ) : (
                          <Link
                            href={item.href}
                            className="text-lg font-medium text-foreground/80 hover:text-primary transition-colors py-2 block"
                          >
                            {item.label}
                          </Link>
                       )}
                     </SheetClose>
                  ))}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
