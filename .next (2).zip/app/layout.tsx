import type {Metadata} from 'next';
import { Geist, Geist_Mono } from 'next/font/google'; // Corrected: GeistSans to Geist
import './globals.css';
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({ // Corrected: GeistSans to Geist
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Sparc Launchpad - Pioneering Aerospace Innovation',
  description: 'Discover Sparc Aerospace: our mission, projects, and the future of space technology. Contact us for collaborations and explore AI-powered space news summaries.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
