import { config } from 'dotenv';
config();

// Removed summarize-space-news.ts import as the feature is removed.
// Add other Genkit flow imports here if needed for development.
