
"use client";

import { useForm, type SubmitHandler, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send, CheckCircle, AlertTriangle } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form, // Added Form import
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";


// Google Form entry IDs
const GOOGLE_FORM_ENTRY_IDS = {
  fullName: "entry.196293708",
  emailAddress: "entry.1786093532",
  phoneNumber: "entry.540748704",
  education: "entry.1029506166",
  expertise: "entry.193124056",
  expertiseOther: "entry.193124056.other_option_response", // Helper for Zod, actual submission handles this
  linkedInGitHub: "entry.856990241",
  availability: "entry.1493855165",
  whyIntern: "entry.466260913",
  // Resume Upload (entry.247353143) is omitted due to submission limitations
};

const joinFormSchema = z.object({
  [GOOGLE_FORM_ENTRY_IDS.fullName]: z.string().min(2, { message: "Full Name must be at least 2 characters." }),
  [GOOGLE_FORM_ENTRY_IDS.emailAddress]: z.string().email({ message: "Please enter a valid email address." }),
  [GOOGLE_FORM_ENTRY_IDS.phoneNumber]: z.string().min(10, { message: "Please enter a valid phone number (min 10 digits)." }).regex(/^\+?[0-9\s-]{10,}$/, "Invalid phone number format."),
  [GOOGLE_FORM_ENTRY_IDS.education]: z.string().min(3, { message: "Please enter your current education/graduation year." }),
  [GOOGLE_FORM_ENTRY_IDS.expertise]: z.string({ required_error: "Please select your area of expertise." }),
  [GOOGLE_FORM_ENTRY_IDS.expertiseOther]: z.string().optional(),
  [GOOGLE_FORM_ENTRY_IDS.linkedInGitHub]: z.string().url({ message: "Please enter a valid URL (e.g., https://...)" }).optional().or(z.literal('')),
  [GOOGLE_FORM_ENTRY_IDS.availability]: z.string({ required_error: "Please select your availability." }),
  [GOOGLE_FORM_ENTRY_IDS.whyIntern]: z.string().min(10, { message: "Please tell us why you want to intern (min 10 characters)." }),
}).refine(data => {
  if (data[GOOGLE_FORM_ENTRY_IDS.expertise] === "__other_option__") {
    return data[GOOGLE_FORM_ENTRY_IDS.expertiseOther] && data[GOOGLE_FORM_ENTRY_IDS.expertiseOther].trim() !== "";
  }
  return true;
}, {
  message: "Please specify your expertise if you select 'Other'.",
  path: [GOOGLE_FORM_ENTRY_IDS.expertiseOther],
});

type JoinFormData = z.infer<typeof joinFormSchema>;

const GOOGLE_FORM_ACTION_URL = "https://docs.google.com/forms/u/0/d/e/1FAIpQLSeulJyp7rJEAzRjlokNqS1AZ072vnf5_A_3WCJ8A1GM5Wc_WQ/formResponse";

const expertiseOptions = [
  "Embedded Systems (ESP32, STM32, etc.)",
  "MATLAB & Simulink",
  "Aerodynamic Analysis",
  "ANSYS /OPENFoam/ Simulations",
  "CAD / Mechanical Design",
  "Branding & Communication",
];

const availabilityOptions = [
  "10 hrs",
  "15 hrs",
];

export function JoinForm() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showOtherExpertise, setShowOtherExpertise] = useState(false);

  const formMethods = useForm<JoinFormData>({ // Store all methods in one object
    resolver: zodResolver(joinFormSchema),
    defaultValues: {
      [GOOGLE_FORM_ENTRY_IDS.fullName]: "",
      [GOOGLE_FORM_ENTRY_IDS.emailAddress]: "",
      [GOOGLE_FORM_ENTRY_IDS.phoneNumber]: "",
      [GOOGLE_FORM_ENTRY_IDS.education]: "",
      [GOOGLE_FORM_ENTRY_IDS.expertiseOther]: "",
      [GOOGLE_FORM_ENTRY_IDS.linkedInGitHub]: "",
      [GOOGLE_FORM_ENTRY_IDS.expertise]: undefined,
      [GOOGLE_FORM_ENTRY_IDS.availability]: undefined,
      [GOOGLE_FORM_ENTRY_IDS.whyIntern]: "",
    }
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
    control,
  } = formMethods; // Destructure for convenience

  const selectedExpertise = watch(GOOGLE_FORM_ENTRY_IDS.expertise);

  useEffect(() => {
    if (selectedExpertise === "__other_option__") {
      setShowOtherExpertise(true);
    } else {
      setShowOtherExpertise(false);
      setValue(GOOGLE_FORM_ENTRY_IDS.expertiseOther, "");
    }
  }, [selectedExpertise, setValue]);

  const onSubmit: SubmitHandler<JoinFormData> = async (data) => {
    setIsSubmitting(true);
    const googleFormData = new FormData();

    const dataForGoogle: Partial<JoinFormData> = { ...data };

    if (dataForGoogle[GOOGLE_FORM_ENTRY_IDS.expertise] === "__other_option__") {
      dataForGoogle[GOOGLE_FORM_ENTRY_IDS.expertise] = dataForGoogle[GOOGLE_FORM_ENTRY_IDS.expertiseOther];
    }
    delete dataForGoogle[GOOGLE_FORM_ENTRY_IDS.expertiseOther];


    Object.entries(dataForGoogle).forEach(([key, value]) => {
      if (value !== undefined && value !== null && String(value).trim() !== "") {
        googleFormData.append(key, String(value));
      }
    });
    
    try {
      await fetch(GOOGLE_FORM_ACTION_URL, {
        method: "POST",
        body: googleFormData,
        mode: "no-cors",
      });

      toast({
        title: "Application Submitted!",
        description: "Your application has been sent to Sparc Launchpad. We'll be in touch if your profile matches our needs.",
        variant: "default",
        action: <CheckCircle className="text-green-500" />,
      });
      reset();
      setShowOtherExpertise(false);
    } catch (error) {
      console.error("Error submitting to Google Form:", error);
      toast({
        title: "Submission Error",
        description: "There was an issue submitting your application. Please try again later.",
        variant: "destructive",
        action: <AlertTriangle className="text-yellow-500" />,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto shadow-xl border border-border/30 rounded-lg">
      <CardHeader>
        <CardTitle className="text-2xl text-primary">Aspiring Innovator Application</CardTitle>
        <CardDescription className="text-foreground/80">
          We're excited to learn more about you! Please fill out the details below.
          <br />
          <strong className="text-destructive/90 block mt-2">Important:</strong> For resume submission, please use the original 
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSeulJyp7rJEAzRjlokNqS1AZ072vnf5_A_3WCJ8A1GM5Wc_WQ/viewform" target="_blank" rel="noopener noreferrer" className="underline hover:text-primary transition-colors"> Google Form</a> or email it as instructed. Direct file uploads are not supported through this page.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...formMethods}> {/* FormProvider wrapper */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.fullName}>Full Name <span className="text-destructive">*</span></Label>
              <Input id={GOOGLE_FORM_ENTRY_IDS.fullName} {...register(GOOGLE_FORM_ENTRY_IDS.fullName)} placeholder="e.g., Ada Lovelace" />
              {errors[GOOGLE_FORM_ENTRY_IDS.fullName] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.fullName]?.message}</p>}
            </div>

            <div>
              <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.emailAddress}>Email Address <span className="text-destructive">*</span></Label>
              <Input id={GOOGLE_FORM_ENTRY_IDS.emailAddress} type="email" {...register(GOOGLE_FORM_ENTRY_IDS.emailAddress)} placeholder="you@example.com" />
              {errors[GOOGLE_FORM_ENTRY_IDS.emailAddress] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.emailAddress]?.message}</p>}
            </div>

            <div>
              <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.phoneNumber}>Phone Number <span className="text-destructive">*</span></Label>
              <Input id={GOOGLE_FORM_ENTRY_IDS.phoneNumber} type="tel" {...register(GOOGLE_FORM_ENTRY_IDS.phoneNumber)} placeholder="e.g., +1 555-123-4567" />
              {errors[GOOGLE_FORM_ENTRY_IDS.phoneNumber] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.phoneNumber]?.message}</p>}
            </div>

            <div>
              <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.education}>Current Education / Graduation Year <span className="text-destructive">*</span></Label>
              <Input id={GOOGLE_FORM_ENTRY_IDS.education} {...register(GOOGLE_FORM_ENTRY_IDS.education)} placeholder="e.g., B.Tech Aerospace / 2025" />
              {errors[GOOGLE_FORM_ENTRY_IDS.education] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.education]?.message}</p>}
            </div>
            
            <FormField
              control={control}
              name={GOOGLE_FORM_ENTRY_IDS.expertise}
              render={({ field }) => (
                <FormItem>
                  <Label>Area of Expertise <span className="text-destructive">*</span></Label>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your area of expertise" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {expertiseOptions.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                      <SelectItem value="__other_option__">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            {showOtherExpertise && (
              <div className="pl-1 pt-2">
                <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.expertiseOther}>Please specify your expertise <span className="text-destructive">*</span></Label>
                <Input
                  id={GOOGLE_FORM_ENTRY_IDS.expertiseOther}
                  {...register(GOOGLE_FORM_ENTRY_IDS.expertiseOther)}
                  placeholder="Your specific expertise"
                  className="mt-1"
                />
                {errors[GOOGLE_FORM_ENTRY_IDS.expertiseOther] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.expertiseOther]?.message}</p>}
              </div>
            )}
            {(errors[GOOGLE_FORM_ENTRY_IDS.expertise] && !showOtherExpertise) && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.expertise]?.message}</p>}


            <div>
              <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.linkedInGitHub}>LinkedIn or GitHub Profile URL</Label>
              <Input id={GOOGLE_FORM_ENTRY_IDS.linkedInGitHub} {...register(GOOGLE_FORM_ENTRY_IDS.linkedInGitHub)} placeholder="https://linkedin.com/in/yourprofile or https://github.com/yourusername" />
              {errors[GOOGLE_FORM_ENTRY_IDS.linkedInGitHub] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.linkedInGitHub]?.message}</p>}
            </div>

            <FormField
              control={control}
              name={GOOGLE_FORM_ENTRY_IDS.availability}
              render={({ field }) => (
                <FormItem>
                  <Label>Availability (Hours per week) <span className="text-destructive">*</span></Label>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your availability" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {availabilityOptions.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            {errors[GOOGLE_FORM_ENTRY_IDS.availability] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.availability]?.message}</p>}

            <div>
              <Label htmlFor={GOOGLE_FORM_ENTRY_IDS.whyIntern}>Why do you want to intern at Sparc Aerotech? <span className="text-destructive">*</span></Label>
              <Textarea
                id={GOOGLE_FORM_ENTRY_IDS.whyIntern}
                {...register(GOOGLE_FORM_ENTRY_IDS.whyIntern)}
                placeholder="Share your motivation, what you hope to learn, or relevant experience (min. 10 characters)."
                rows={5}
              />
              {errors[GOOGLE_FORM_ENTRY_IDS.whyIntern] && <p className="mt-1 text-sm text-destructive">{errors[GOOGLE_FORM_ENTRY_IDS.whyIntern]?.message}</p>}
            </div>

            <Button type="submit" disabled={isSubmitting} className="w-full group text-base py-3">
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Submitting Application...
                </>
              ) : (
                <>
                  Submit Application
                  <Send className="ml-2 h-5 w-5 transform transition-transform duration-300 group-hover:translate-x-1" />
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
