
// src/lib/actions.ts
"use server";

import { z } from "zod";

export interface ContactFormState {
  message: string;
  errors?: {
    name?: string[];
    email?: string[];
    message?: string[];
    _form?: string[]; // For general form errors
  };
  success: boolean;
}

const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters long." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters long." }),
});

export async function submitContactForm(
  prevState: ContactFormState | undefined,
  formData: FormData
): Promise<ContactFormState> {
  const validatedFields = contactFormSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    message: formData.get("message"),
  });

  if (!validatedFields.success) {
    return {
      errors: validatedFields.error.flatten().fieldErrors,
      message: "Validation failed. Please check the fields.",
      success: false,
    };
  }

  // Simulate API call or email sending
  console.log("Contact Form Submitted:", validatedFields.data);
  
  try {
    // Replace with actual email sending logic
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate network delay

    return { message: "Thank you for your message! We'll be in touch soon.", success: true };
  } catch (error) {
    console.error("Failed to submit contact form:", error);
    return { 
      message: "An unexpected error occurred. Please try again later.", 
      success: false,
      errors: { _form: ["Submission failed due to a server error."] }
    };
  }
}


// --- Join Us Form (Logic removed as it's now handled by client-side submission to Google Forms) ---
// export interface JoinFormState {
//   message: string;
//   errors?: {
//     name?: string[];
//     email?: string[];
//     linkedinProfile?: string[];
//     areaOfInterest?: string[];
//     message?: string[];
//     _form?: string[];
//   };
//   success: boolean;
// }

// const joinFormSchema = z.object({
//   name: z.string().min(2, { message: "Name must be at least 2 characters." }),
//   email: z.string().email({ message: "Invalid email address." }),
//   linkedinProfile: z.string().url({ message: "Please enter a valid URL." }).optional().or(z.literal('')),
//   areaOfInterest: z.enum(["engineering", "science", "design", "business_development", "operations", "other"], {
//     errorMap: () => ({ message: "Please select an area of interest." })
//   }),
//   message: z.string().min(10, { message: "Message must be at least 10 characters to share your motivation or details." }).optional().or(z.literal('')),
// });

// export async function submitJoinForm(
//   prevState: JoinFormState | undefined,
//   formData: FormData
// ): Promise<JoinFormState> {
//   const rawFormData = {
//     name: formData.get("name"),
//     email: formData.get("email"),
//     linkedinProfile: formData.get("linkedinProfile") || "", // Ensure empty string if null
//     areaOfInterest: formData.get("areaOfInterest"),
//     message: formData.get("message") || "", // Ensure empty string if null
//   };

//   const validatedFields = joinFormSchema.safeParse(rawFormData);

//   if (!validatedFields.success) {
//     return {
//       errors: validatedFields.error.flatten().fieldErrors,
//       message: "Validation failed. Please check the fields below.",
//       success: false,
//     };
//   }
  
//   // Simulate processing application
//   console.log("Join Form Submitted:", validatedFields.data);

//   try {
//     // Replace with actual application processing logic (e.g., save to database, send notification)
//     await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate network delay

//     return { message: "Thank you for your application! We've received your details and will be in touch if your profile matches our needs.", success: true };
//   } catch (error) {
//     console.error("Failed to submit join form:", error);
//     return { 
//       message: "An unexpected error occurred while submitting your application. Please try again later.", 
//       success: false,
//       errors: { _form: ["Submission failed due to a server error."] }
//     };
//   }
// }

